package com.example.jsonparsing;

import android.app.Activity;
import android.os.Bundle;

public class ContactActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_item);
	}

}
